config = {
  'host': 'localhost',
  'user': 'root',
  'password': '',
  'db': 'barcantina'
}
