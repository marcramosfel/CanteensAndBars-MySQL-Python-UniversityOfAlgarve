1. Para correr este código é necessário ter intalado o mysql-connector-python

``` 
$ pip install jupyter
$ pip install mysql-connector-python
```
2. Para correr os notebooks (.ipynb) começar por pôr a correr o jupyter (numa consola)

```
$ jupyter-notebook
``` 

3. Supõe-se ainda que no MySQL existe um utilizador com
    login: adam
    pw: adam
    - permissões necessários para trabalhar com a base de dados Adamastor 
    - podem dar essas permissões usando phpmyadmin 
        (ligar apache server e mysql server; aceda a http://localhost/phpmyadmin/index.php)