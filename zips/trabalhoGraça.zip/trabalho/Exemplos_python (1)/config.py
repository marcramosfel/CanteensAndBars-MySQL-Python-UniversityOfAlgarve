config = {
  'host': 'localhost',
  'user': 'adam',
  'password': 'adam',
  'db': 'adamastor'
}
