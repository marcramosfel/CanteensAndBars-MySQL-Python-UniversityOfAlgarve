from pratos import *
from produtos import *
from categoriaPrato import *
from categoriaProdutos import *
from precoPratoEspacoAlimentar import *
from precoProdutoEspacoAlimentar import *
from produtosFornecedores import *
from avaliacao import *

def mostra_menu_le_opcao():
    print(80 * "#")
    print("""Menu Global
                1 - Pratos
                2 - Produtos
                3 - Categoria Pratos
                4 - Categoria dos Produtos
                5 - Preços dos Pratos Dependendo do Bar
                6 - Preço dos Produtos Dependendo do Bar
                7 - Preços dos Produtos Dependendo do Fornecedor
                8 - Avaliação dos Espaços Alimentares
                
            x - sair
        """)
    print(80 * "#")
    op = input("opção? ")
    print(80 * "#")
    return op

def main():
    print('''BEM VINDO A BASE DE DADOS BAR E CANTINAS DA UNIVERSIDADE DO ALGARVE
            
Através deste programa pode gerir os dados presentes na base de dados!''')
    while True:
        op = mostra_menu_le_opcao()
        if op == "1":  # lista todos os clientes
            main_pratos()
        elif op == "3":  # lista todos os clientes
            main_categoriaPratos()
        elif op == "5":
            main_preco_prato_espacoalimentar()
        elif op == "2":
            main_produtos()
        elif op == "4":
            main_categoriaprodutos()
        elif op == "7":
            main_produtos_fornecedores()
        elif op == "6":
            main_preco_produto_espacoalimentar()
        elif op == "8":
            main_avaliacao()
        elif op == "x":
            print('''Projeto desenvolvido por:
Marcos Ramos a63059''')
            break

if __name__ == "__main__":
    main()
